export default {
 'tabbar.cleseCurrent': 'Close the current',
  'tabbar.closeOther': 'Close others',
  'tabbar.closeAll': 'Close all',
  'tabbar.reloading': 'reloading',
  'tabbar.closeCurrent': 'Close the current tabs',
  'tabbar.closeLeft': 'Close the left tabs',
  'tabbar.closeRight': 'Close the right tabs',
  'tabbar.closeOtherTabs': 'Close other tabs',
  'tabbar.closeAllTabs': 'Close all tabs',
};
