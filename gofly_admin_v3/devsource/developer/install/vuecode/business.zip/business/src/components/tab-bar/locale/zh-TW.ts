export default {
  'tabbar.cleseCurrent': '關閉當前',
  'tabbar.closeOther': '關閉其他',
  'tabbar.closeAll': '關閉全部',
  'tabbar.reloading': '重新加載',
  'tabbar.closeCurrent': '關閉當前標籤頁',
  'tabbar.closeLeft': '關閉左側標籤頁',
  'tabbar.closeRight': '關閉右側標籤頁',
  'tabbar.closeOtherTabs': '關閉其它標籤頁',
  'tabbar.closeAllTabs': '關閉全部標籤頁',
};
