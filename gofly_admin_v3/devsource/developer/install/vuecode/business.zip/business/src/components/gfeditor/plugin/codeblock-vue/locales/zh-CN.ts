export default {
	codeblock: {
		autoWrap: '自动换行',
	},
};
