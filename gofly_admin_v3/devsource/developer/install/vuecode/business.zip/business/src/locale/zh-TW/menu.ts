export default {
  'menu.home': '控製枱',
  'menu.exception': '異常頁',
  'menu.user': '個人中心',
  'menu.system':"係統管理",
  'menu.datacenter': '數據中心',

};
