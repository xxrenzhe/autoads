import tabletool from './index.vue';
export * from './data';

export { tabletool }