import ColorTool from './color';
import Palette from './palette';
import './index.css';

export { ColorTool, Palette };
