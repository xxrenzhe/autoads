import DefaultKeydown from '../keydown/default';

class DefaultKeyup extends DefaultKeydown {
	type: 'keydown' | 'keyup' = 'keyup';
}

export default DefaultKeyup;
