export default {
	status: {
		defaultValue: 'SET A STATUS',
	},
};
