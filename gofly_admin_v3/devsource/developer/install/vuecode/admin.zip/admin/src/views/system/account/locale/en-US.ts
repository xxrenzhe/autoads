export default {
  'menu.system.account': 'account',
};
