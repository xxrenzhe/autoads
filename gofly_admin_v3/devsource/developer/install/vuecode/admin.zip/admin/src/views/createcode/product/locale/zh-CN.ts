export default {
  'store.article.title': '文章管理',
};
