export default {
  'menu.system.account': '账号管理',
};
