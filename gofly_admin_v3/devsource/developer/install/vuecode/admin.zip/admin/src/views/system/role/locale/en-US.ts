export default {
  'system.role': 'Role management',
};
