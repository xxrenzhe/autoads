declare module 'qs' {
    const content: any
    export = content
  }