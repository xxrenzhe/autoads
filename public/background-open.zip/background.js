// Background service worker for Background Tab Opener extension

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    // Respond to ping for extension detection
    sendResponse({ 
      success: true, 
      message: "Extension is installed and running",
      version: "1.0.0"
    });
    return true;
  }
  
  if (request.action === "openBackgroundTab") {
    // Open new tab in background (active: false)
    chrome.tabs.create({ 
      url: request.url, 
      active: false 
    }, (tab) => {
      // Send response with tab info
      sendResponse({ 
        success: true, 
        tabId: tab.id,
        message: "Tab opened in background"
      });
    });
    
    // Return true to indicate we will send a response asynchronously
    return true;
  }
  
  if (request.action === "openMultipleBackgroundTabs") {
    const urls = request.urls;
    const results = [];
    
    // Open multiple tabs in background
    urls.forEach((url, index) => {
      setTimeout(() => {
        chrome.tabs.create({ 
          url: url, 
          active: false 
        }, (tab) => {
          results.push({
            url: url,
            tabId: tab.id,
            success: true
          });
          
          // Send progress update
          chrome.runtime.sendMessage({
            action: "tabOpened",
            progress: {
              current: index + 1,
              total: urls.length,
              url: url,
              tabId: tab.id
            }
          });
        });
      }, index * request.interval || 0);
    });
    
    sendResponse({ 
      success: true, 
      message: `Opening ${urls.length} tabs in background`,
      total: urls.length
    });
    
    return true;
  }
  
  if (request.action === "closeTabs") {
    // Close specified tabs
    const tabIds = request.tabIds || [];
    tabIds.forEach(tabId => {
      chrome.tabs.remove(tabId, () => {
        // Tab closed
      });
    });
    sendResponse({ 
      success: true, 
      message: `Closing ${tabIds.length} tabs`
    });
    return true;
  }
  
  if (request.action === "closeAllBackgroundTabs") {
    // Close all background tabs (non-active tabs)
    chrome.tabs.query({ active: false }, (tabs) => {
      const backgroundTabIds = tabs.map(tab => tab.id);
      backgroundTabIds.forEach(tabId => {
        chrome.tabs.remove(tabId, () => {
          // Tab closed
        });
      });
      sendResponse({ 
        success: true, 
        message: `Closing ${backgroundTabIds.length} background tabs`
      });
    });
    return true;
  }
});

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("Background Tab Opener extension installed");
  }
});

// Handle tab updates to maintain focus control
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Optional: Add any additional tab management logic here
  if (changeInfo.status === "complete") {
    // Tab has finished loading
  }
}); 