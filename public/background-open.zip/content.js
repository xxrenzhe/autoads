// Content script for Background Tab Opener extension

// 注入 window.backgroundOpenExtension 到页面作用域
const script = document.createElement('script');
script.textContent = 'window.backgroundOpenExtension = { id: "' + chrome.runtime.id + '" };';
(document.head || document.documentElement).appendChild(script);
script.remove();

// Configuration
const CONFIG = {
  // Selectors for links that should open in background
  linkSelectors: [
    'a[href]',
    'a[data-background-tab]',
    '.background-tab-link'
  ],
  
  // Attributes that indicate background opening
  backgroundAttributes: [
    'data-background-tab',
    'data-bg-tab',
    'rel="background"'
  ],
  
  // Modifier keys for background opening
  modifierKeys: {
    ctrl: false,  // Ctrl+Click
    shift: false, // Shift+Click
    alt: false,   // Alt+Click
    meta: false   // Cmd+Click (Mac)
  }
};

// Initialize the content script
function init() {
  // Add event listeners for link clicks
  document.addEventListener('click', handleLinkClick, true);
  
  // Add visual indicators for background tab links
  addVisualIndicators();
  
  // Listen for messages from background script
  chrome.runtime.onMessage.addListener(handleBackgroundMessage);

// Listen for messages from the webpage
window.addEventListener('message', (event) => {
  // Only accept messages from the same origin
  if (event.source !== window) return;
  
  if (event.data.type === 'BATCH_OPEN_URLS') {
    handleBatchOpenRequest(event.data);
  }
});
  
  console.log('Background Tab Opener content script loaded');
}

// Handle link click events
function handleLinkClick(event) {
  const link = event.target.closest('a[href]');
  if (!link) return;
  
  // Check if this link should open in background
  if (shouldOpenInBackground(link, event)) {
    event.preventDefault();
    event.stopPropagation();
    
    const url = link.href;
    openInBackgroundTab(url, link);
  }
}

// Determine if a link should open in background
function shouldOpenInBackground(link, event) {
  // Check for background attributes
  for (const attr of CONFIG.backgroundAttributes) {
    if (link.hasAttribute(attr.replace('data-', '').replace('rel="', '').replace('"', ''))) {
      return true;
    }
  }
  
  // Check for modifier keys
  if (CONFIG.modifierKeys.ctrl && event.ctrlKey) return true;
  if (CONFIG.modifierKeys.shift && event.shiftKey) return true;
  if (CONFIG.modifierKeys.alt && event.altKey) return true;
  if (CONFIG.modifierKeys.meta && event.metaKey) return true;
  
  // Check for specific classes or IDs
  if (link.classList.contains('background-tab-link')) return true;
  if (link.id && link.id.includes('background-tab')) return true;
  
  return false;
}

// Open URL in background tab
function openInBackgroundTab(url, linkElement) {
  // Send message to background script
  chrome.runtime.sendMessage({
    action: "openBackgroundTab",
    url: url,
    source: {
      page: window.location.href,
      linkText: linkElement.textContent.trim(),
      linkTitle: linkElement.title || linkElement.textContent.trim()
    }
  }, (response) => {
    if (response && response.success) {
      // Show success indicator
      showSuccessIndicator(linkElement);
      
      // Optional: Add to opened tabs tracking
      trackOpenedTab(url, response.tabId);
    } else {
      console.error('Failed to open background tab:', response);
    }
  });
}

// Show visual success indicator
function showSuccessIndicator(linkElement) {
  // Add temporary success class
  linkElement.classList.add('background-tab-opened');
  
  // Remove after animation
  setTimeout(() => {
    linkElement.classList.remove('background-tab-opened');
  }, 1000);
}

// Track opened tabs (optional)
function trackOpenedTab(url, tabId) {
  // Store in session storage for tracking
  const openedTabs = JSON.parse(sessionStorage.getItem('backgroundTabs') || '[]');
  openedTabs.push({
    url: url,
    tabId: tabId,
    openedAt: new Date().toISOString()
  });
  sessionStorage.setItem('backgroundTabs', JSON.stringify(openedTabs));
}

// Add visual indicators to background tab links
function addVisualIndicators() {
  const links = document.querySelectorAll(CONFIG.linkSelectors.join(', '));
  
  links.forEach(link => {
    if (shouldOpenInBackground(link, {})) {
      link.classList.add('background-tab-indicator');
      
      // Add tooltip
      if (!link.title) {
        link.title = 'Opens in background tab';
      }
    }
  });
}

// Handle messages from background script
function handleBackgroundMessage(message, sender, sendResponse) {
  if (message.action === "tabOpened") {
    // Handle progress updates for multiple tabs
    console.log(`Tab opened: ${message.progress.url}`);
    
    // Update UI if needed
    updateProgressIndicator(message.progress);
  }
}

// Handle batch open request from webpage
function handleBatchOpenRequest(data) {
  const { urls, interval = 500 } = data;
  
  if (!urls || !Array.isArray(urls) || urls.length === 0) {
    sendResponseToPage({
      type: 'BATCH_OPEN_RESPONSE',
      success: false,
      error: 'No valid URLs provided'
    });
    return;
  }
  
  // Send message to background script to open multiple tabs
  chrome.runtime.sendMessage({
    action: "openMultipleBackgroundTabs",
    urls: urls,
    interval: interval
  }, (response) => {
    if (response && response.success) {
      sendResponseToPage({
        type: 'BATCH_OPEN_RESPONSE',
        success: true,
        message: `Opening ${urls.length} tabs in background`,
        total: urls.length
      });
    } else {
      sendResponseToPage({
        type: 'BATCH_OPEN_RESPONSE',
        success: false,
        error: 'Failed to open tabs'
      });
    }
  });
}

// Send response back to webpage
function sendResponseToPage(response) {
  window.postMessage(response, '*');
}

// Update progress indicator for multiple tabs
function updateProgressIndicator(progress) {
  // Find or create progress indicator
  let indicator = document.getElementById('background-tab-progress');
  if (!indicator) {
    indicator = document.createElement('div');
    indicator.id = 'background-tab-progress';
    indicator.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #4CAF50;
      color: white;
      padding: 10px 15px;
      border-radius: 5px;
      z-index: 10000;
      font-size: 14px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    `;
    document.body.appendChild(indicator);
  }
  
  indicator.textContent = `Opening tabs: ${progress.current}/${progress.total}`;
  
  // Remove indicator when complete
  if (progress.current >= progress.total) {
    setTimeout(() => {
      if (indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
      }
    }, 2000);
  }
}

// Add CSS styles for visual indicators
function addStyles() {
  const style = document.createElement('style');
  style.textContent = `
    .background-tab-indicator::after {
      content: "↗";
      margin-left: 4px;
      font-size: 12px;
      opacity: 0.7;
    }
    
    .background-tab-opened {
      animation: backgroundTabSuccess 1s ease-in-out;
    }
    
    @keyframes backgroundTabSuccess {
      0% { background-color: transparent; }
      50% { background-color: #4CAF50; color: white; }
      100% { background-color: transparent; }
    }
  `;
  document.head.appendChild(style);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    addStyles();
    init();
  });
} else {
  addStyles();
  init();
} 