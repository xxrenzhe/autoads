const fs = require('fs');
const { createCanvas } = require('canvas');

// 如果没有canvas模块，使用简单的SVG生成
function createSVGIcon(size) {
    const center = size / 2;
    const fontSize = Math.floor(size * 0.4);
    
    return `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <radialGradient id="grad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" style="stop-color:#4CAF50;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#2E7D32;stop-opacity:1" />
            </radialGradient>
        </defs>
        <rect width="${size}" height="${size}" fill="url(#grad)" rx="${size * 0.2}"/>
        <text x="${center}" y="${center}" font-family="Arial, sans-serif" font-size="${fontSize}" font-weight="bold" 
              text-anchor="middle" dominant-baseline="middle" fill="white">B</text>
        <rect x="${size * 0.1}" y="${size * 0.7}" width="${size * 0.8}" height="${size * 0.2}" 
              fill="rgba(255,255,255,0.3)" rx="${size * 0.05}"/>
        <circle cx="${center * 0.7}" cy="${center * 0.7}" r="${size * 0.15}" fill="rgba(255,255,255,0.2)"/>
    </svg>`;
}

function createPNGIcon(size) {
    try {
        const canvas = createCanvas(size, size);
        const ctx = canvas.getContext('2d');
        const center = size / 2;
        
        // Background gradient
        const gradient = ctx.createRadialGradient(center, center, 0, center, center, size/2);
        gradient.addColorStop(0, '#4CAF50');
        gradient.addColorStop(1, '#2E7D32');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, size, size);
        
        // Draw a stylized "B" for Background
        ctx.fillStyle = 'white';
        ctx.font = `bold ${size * 0.4}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('B', center, center);
        
        // Add a small tab icon overlay
        ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.fillRect(size * 0.1, size * 0.7, size * 0.8, size * 0.2);
        
        // Add some shine effect
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.beginPath();
        ctx.arc(center * 0.7, center * 0.7, size * 0.15, 0, Math.PI * 2);
        ctx.fill();
        
        return canvas.toBuffer('image/png');
    } catch (error) {
        console.log('Canvas not available, using SVG fallback');
        return null;
    }
}

function generateIcons() {
    const sizes = [16, 48, 128];
    
    sizes.forEach(size => {
        const filename = `icon${size}.png`;
        
        // Try to create PNG first
        const pngBuffer = createPNGIcon(size);
        
        if (pngBuffer) {
            fs.writeFileSync(filename, pngBuffer);
            console.log(`✅ Created ${filename}`);
        } else {
            // Fallback to SVG
            const svgContent = createSVGIcon(size);
            fs.writeFileSync(filename.replace('.png', '.svg'), svgContent);
            console.log(`⚠️  Created ${filename.replace('.png', '.svg')} (PNG fallback)`);
        }
    });
}

// Generate icons
console.log('🎯 Generating Background Open Extension Icons...');
generateIcons();
console.log('✨ Icon generation complete!');
console.log('');
console.log('📋 Next steps:');
console.log('1. If you got SVG files, convert them to PNG using an online converter');
console.log('2. Or use the generate-icons.html file in a browser to download PNG files');
console.log('3. Place the icon files in the same directory as manifest.json');
console.log('4. Reload the extension in Chrome'); 