const fs = require('fs');

// 纯色绿色小图标（用在线工具生成的简单绿色方块PNG）
const icons = {
  16: 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAAAIUlEQVR4AWMYBaNgFIyCwMAwCjAqQwMDAwMDAwMDAwMDAwAAAwA4nQn6QAAAABJRU5ErkJggg==',
  48: 'iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAQAAAB6y4YfAAAAIUlEQVR4AWMYBaNgFIyCwMAwCjAqQwMDAwMDAwMDAwMDAwAAAwA4nQn6QAAAABJRU5ErkJggg==',
  128: 'iVBORw0KGgoAAAANSUhEUgAAAI AAAACACAYAAADDPmHLAAAAIUlEQVR4AWMYBaNgFIyCwMAwCjAqQwMDAwMDAwMDAwMDAwAAAwA4nQn6QAAAABJRU5ErkJggg=='
};

Object.entries(icons).forEach(([size, base64]) => {
  fs.writeFileSync(`icon${size}.png`, Buffer.from(base64, 'base64'));
  console.log(`icon${size}.png created.`);
});

console.log('All icons created. 请将 icon16.png, icon48.png, icon128.png 放到 background-open 目录下。'); 