# Background Open Chrome Extension - 解决方案总结

## 问题描述

您想要实现在Chrome浏览器中"在当前标签页点击链接时后台打开新标签页且不跳转"的功能。

## 解决方案

我为您创建了一个完整的Chrome扩展程序，通过以下技术方案实现：

### 核心技术原理

1. **Chrome Extension API**: 使用 `chrome.tabs.create({ url: '链接URL', active: false })`
2. **Content Script**: 注入到网页中拦截链接点击事件
3. **Background Service Worker**: 处理后台标签页创建
4. **Message Passing**: 在content script和background script之间通信

### 实现方式

#### 方法1: HTML属性
```html
<a href="https://example.com" data-background-tab>在后台打开</a>
```

#### 方法2: CSS类
```html
<a href="https://example.com" class="background-tab-link">在后台打开</a>
```

#### 方法3: 修饰键
- Ctrl + 点击 (Windows/Linux)
- Cmd + 点击 (Mac)
- Shift + 点击
- Alt + 点击

#### 方法4: 扩展弹窗
点击扩展图标，使用"在后台打开当前页面"按钮

## 文件结构

```
background-open/
├── manifest.json          # 扩展清单文件
├── background.js          # 后台服务工作者
├── content.js            # 内容脚本
├── popup.html            # 扩展弹窗UI
├── popup.js              # 弹窗功能
├── test-page.html        # 测试页面
├── generate-icons.html    # 图标生成器
├── install-instructions.md # 安装说明
├── README.md             # 详细文档
└── SUMMARY.md            # 本文件
```

## 安装步骤

1. **下载扩展文件**
   - 下载 `background-open` 文件夹

2. **在Chrome中加载**
   - 打开 `chrome://extensions/`
   - 启用"开发者模式"
   - 点击"加载已解压的扩展程序"
   - 选择 `background-open` 文件夹

3. **生成图标** (可选)
   - 打开 `generate-icons.html`
   - 下载生成的图标文件
   - 保存到 `background-open` 文件夹

4. **测试功能**
   - 打开 `test-page.html` 进行测试
   - 或访问任何网页，添加 `data-background-tab` 属性到链接

## 功能特性

### ✅ 已实现功能
- [x] 后台标签页打开 (active: false)
- [x] 多种触发方式 (属性、类、修饰键)
- [x] 视觉指示器 (箭头图标)
- [x] 成功动画效果
- [x] 进度跟踪 (多标签页)
- [x] 设置管理 (修饰键配置)
- [x] 标签页历史记录
- [x] 扩展弹窗界面
- [x] 测试页面
- [x] 图标生成器

### 🔧 技术特点
- **Manifest V3**: 使用最新的Chrome扩展标准
- **Service Worker**: 后台脚本使用Service Worker
- **Content Script**: 注入到所有网页
- **Message Passing**: 安全的跨脚本通信
- **Storage API**: 保存用户设置
- **Visual Feedback**: 用户友好的视觉反馈

## 使用方法

### 对于网站开发者
```javascript
// 检查扩展是否可用
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
    console.log('Background Open 扩展已安装');
}

// 程序化打开后台标签页
chrome.runtime.sendMessage({
    action: "openBackgroundTab",
    url: "https://example.com"
}, (response) => {
    if (response.success) {
        console.log('标签页已在后台打开');
    }
});
```

### 对于普通用户
1. 安装扩展后，任何带有 `data-background-tab` 属性的链接都会在后台打开
2. 可以在扩展弹窗中配置修饰键
3. 使用修饰键 + 点击可以打开任何链接在后台

## 优势

1. **无需修改网站代码**: 通过扩展实现，不影响现有网站
2. **多种触发方式**: 灵活的使用方式
3. **用户友好**: 清晰的视觉指示和反馈
4. **性能优化**: 轻量级实现，不影响浏览器性能
5. **跨平台**: 支持Chrome、Edge等Chromium内核浏览器

## 限制

1. **仅限Chrome扩展**: 只能在支持Chrome扩展的浏览器中使用
2. **需要用户安装**: 用户需要手动安装扩展
3. **权限要求**: 需要tabs和activeTab权限

## 替代方案

如果不想使用Chrome扩展，还可以考虑：

1. **浏览器原生功能**: 中键点击或Ctrl+点击
2. **JavaScript实现**: 使用 `window.open()` 但效果有限
3. **其他浏览器扩展**: 类似功能的现有扩展

## 总结

这个Chrome扩展完美解决了您提出的问题，提供了完整的"后台打开标签页不跳转"功能。通过多种触发方式和用户友好的界面，让用户可以轻松地在后台打开链接而不会失去当前页面的焦点。

扩展采用现代Chrome扩展开发标准，代码结构清晰，易于维护和扩展。同时提供了完整的文档和测试工具，方便开发和部署。 