# Background Open Chrome Extension

A Chrome extension that allows you to open links in background tabs without switching focus from the current page.

## Features

- **Background Tab Opening**: Open links in new tabs without switching focus
- **Multiple Trigger Methods**: 
  - HTML attributes (`data-background-tab`)
  - CSS classes (`background-tab-link`)
  - Modifier keys (Ctrl, Shift, Alt, Cmd)
- **Visual Indicators**: Links that open in background show a small arrow indicator
- **Progress Tracking**: Track multiple tabs being opened with progress indicators
- **Settings Management**: Configure which modifier keys trigger background opening
- **Tab History**: Keep track of opened background tabs

## Installation

### Method 1: Load Unpacked Extension (Development)

1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the `background-open` folder
5. The extension should now appear in your extensions list

### Method 2: Install from Chrome Web Store (Coming Soon)

1. Visit the Chrome Web Store (link will be added when published)
2. Click "Add to Chrome"
3. Confirm the installation

## Usage

### Method 1: HTML Attributes

Add the `data-background-tab` attribute to any link:

```html
<a href="https://example.com" data-background-tab>Open in Background</a>
```

### Method 2: CSS Classes

Add the `background-tab-link` class to any link:

```html
<a href="https://example.com" class="background-tab-link">Open in Background</a>
```

### Method 3: Modifier Keys

Enable modifier keys in the extension popup, then use:
- **Ctrl + Click** (Windows/Linux)
- **Cmd + Click** (Mac)
- **Shift + Click**
- **Alt + Click**

### Method 4: Extension Popup

1. Click the extension icon in your browser toolbar
2. Use the "Open Current Page in Background" button
3. Configure modifier key settings

## Configuration

### Modifier Keys

Open the extension popup to configure which modifier keys trigger background tab opening:

- **Ctrl + Click**: Opens link in background when Ctrl is held
- **Shift + Click**: Opens link in background when Shift is held  
- **Alt + Click**: Opens link in background when Alt is held
- **Cmd + Click**: Opens link in background when Cmd is held (Mac)

### Visual Indicators

Links that will open in background tabs show:
- A small arrow (↗) after the link text
- A tooltip saying "Opens in background tab"
- A brief green highlight animation when clicked

## API Integration

### For Web Developers

You can integrate this extension with your web applications:

```javascript
// Check if extension is available
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
  // Extension is installed
  console.log('Background Open extension is available');
}

// Programmatically open tabs in background
chrome.runtime.sendMessage({
  action: "openBackgroundTab",
  url: "https://example.com"
}, (response) => {
  if (response.success) {
    console.log('Tab opened in background');
  }
});

// Open multiple tabs with intervals
chrome.runtime.sendMessage({
  action: "openMultipleBackgroundTabs",
  urls: ["https://example1.com", "https://example2.com"],
  interval: 1000 // 1 second between each tab
});
```

## File Structure

```
background-open/
├── manifest.json          # Extension manifest
├── background.js          # Background service worker
├── content.js            # Content script (injected into pages)
├── popup.html            # Extension popup UI
├── popup.js              # Popup functionality
├── icon16.png            # 16x16 icon
├── icon48.png            # 48x48 icon
├── icon128.png           # 128x128 icon
└── README.md             # This file
```

## Permissions

This extension requires the following permissions:

- **`tabs`**: To create new tabs in the background
- **`activeTab`**: To access the current tab for popup functionality
- **`storage`**: To save user settings and preferences

## Browser Compatibility

- Chrome 88+ (Manifest V3)
- Edge 88+ (Chromium-based)
- Other Chromium-based browsers

## Development

### Building from Source

1. Clone the repository
2. Make your changes to the source files
3. Load the extension in Chrome using "Load unpacked"
4. Test your changes

### Adding Icons

Replace the placeholder icon files with your own:
- `icon16.png` (16x16 pixels)
- `icon48.png` (48x48 pixels)  
- `icon128.png` (128x128 pixels)

### Publishing to Chrome Web Store

1. Create a ZIP file of the `background-open` folder
2. Go to the [Chrome Developer Dashboard](https://chrome.google.com/webstore/devconsole/)
3. Upload your extension
4. Fill in the required information
5. Submit for review

## Troubleshooting

### Extension Not Working

1. Check if the extension is enabled in `chrome://extensions/`
2. Refresh the page you're testing on
3. Check the browser console for any error messages
4. Try disabling other extensions that might interfere

### Links Not Opening in Background

1. Make sure you're using one of the supported methods (attributes, classes, or modifier keys)
2. Check the extension popup to see if modifier keys are enabled
3. Verify the link has a valid `href` attribute

### Performance Issues

1. The extension is lightweight and shouldn't impact performance
2. If you experience issues, try disabling the extension temporarily
3. Check if you have many tabs open, as this can affect browser performance

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

If you encounter any issues or have questions:

1. Check the troubleshooting section above
2. Open an issue on GitHub
3. Contact the development team

## Download

**Latest Version: v1.2.5**

- [Download v1.2.5](../background-open-v1.2.5.zip) - Latest stable version with syntax fixes

### Previous Versions
- [Download v1.2.4](../background-open-v1.2.4.zip) - Previous version (has syntax issues)
- [Download v1.2.3](../background-open-v1.2.3.zip)
- [Download v1.2.2](../background-open-v1.2.2.zip)

## Changelog

### Version 1.2.5 (Latest)
- **Fixed**: Syntax error in background.js that caused installation failure
- **Fixed**: Removed extra closing bracket that prevented service worker registration
- **Improved**: Code stability and error handling

### Version 1.2.4
- Enhanced batch opening functionality
- Improved tab management and termination
- Added progress tracking for batch operations
- **Note**: Contains syntax error, use v1.2.5 instead

### Version 1.2.3
- Added batch tab termination functionality
- Improved error handling
- Enhanced tab queue management

### Version 1.2.2
- Improved tab opening performance
- Added timeout management
- Enhanced background script reliability

### Version 1.0.0
- Initial release
- Background tab opening functionality
- Multiple trigger methods
- Visual indicators
- Settings management
- Progress tracking 