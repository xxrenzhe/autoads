# Background Open Chrome Extension Installation Instructions

## Quick Installation Guide

### Step 1: Download the Extension
1. Download the `background-open` folder from this repository
2. Extract it to a location on your computer

### Step 2: Load in Chrome
1. Open Google Chrome
2. Navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top-right corner)
4. Click "Load unpacked"
5. Select the `background-open` folder you downloaded
6. The extension should now appear in your extensions list

### Step 3: Verify Installation
1. Look for the extension icon in your Chrome toolbar
2. Click on any webpage
3. Try adding `data-background-tab` to a link and clicking it
4. The link should open in a background tab

## Creating Icons (Optional)

If you want custom icons, create these files in the `background-open` folder:

- `icon16.png` - 16x16 pixels
- `icon48.png` - 48x48 pixels  
- `icon128.png` - 128x128 pixels

You can use any image editor or online icon generator to create these.

## Testing the Extension

### Test Method 1: HTML Attributes
Add this to any webpage:
```html
<a href="https://www.google.com" data-background-tab>Test Link</a>
```

### Test Method 2: CSS Classes
Add this to any webpage:
```html
<a href="https://www.google.com" class="background-tab-link">Test Link</a>
```

### Test Method 3: Extension Popup
1. Click the extension icon in your toolbar
2. Click "Open Current Page in Background"
3. The current page should open in a new background tab

## Troubleshooting

### Extension Not Loading
- Make sure you selected the correct folder (should contain `manifest.json`)
- Check that "Developer mode" is enabled
- Try refreshing the extensions page

### Extension Not Working
- Refresh the webpage you're testing on
- Check the browser console for errors (F12 → Console)
- Make sure the extension is enabled in the extensions list

### Permission Issues
- The extension needs "tabs" and "activeTab" permissions
- These are automatically requested when you load the extension

## Updating the Extension

To update the extension after making changes:
1. Go to `chrome://extensions/`
2. Find the extension in the list
3. Click the refresh icon next to it
4. Or click "Load unpacked" again and select the updated folder

## Uninstalling

To remove the extension:
1. Go to `chrome://extensions/`
2. Find the extension in the list
3. Click "Remove"
4. Confirm the removal 