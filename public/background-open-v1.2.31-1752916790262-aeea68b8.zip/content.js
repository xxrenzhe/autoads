// Content script for Background Tab Opener extension

// 立即执行，确保在页面加载前就设置好变量
(function() {
  console.log('🚀 background-open content script injected');
  
  // 获取扩展ID，兼容不同环境
  let extensionId;
  try {
    extensionId = chrome.runtime.id;
  } catch (error) {
    console.log('⚠️ 无法获取chrome.runtime.id，使用备用ID');
    extensionId = 'background-open-extension';
  }
  
  console.log('📢 设置扩展检测变量，ID:', extensionId);
  
  // 立即设置window变量（最重要的检测方式）
  window.backgroundOpenExtension = {
    id: extensionId
  };
  
  // 设置其他检测标记
  window.backgroundOpenContentScriptLoaded = true;
  window.backgroundOpenExtensionId = extensionId;
  
  // 触发检测事件
  function triggerExtensionDetected() {
    try {
      // 方法1：CustomEvent
      window.dispatchEvent(new CustomEvent('backgroundOpenExtensionDetected', {
        detail: { id: extensionId }
      }));
      
      // 方法2：确保window变量存在
      if (!window.backgroundOpenExtension) {
        window.backgroundOpenExtension = { id: extensionId };
      }
      
      // 方法3：添加DOM标记
      if (!document.querySelector('script[data-background-open]')) {
        const script = document.createElement('script');
        script.setAttribute('data-background-open', 'true');
        script.setAttribute('data-extension-id', extensionId);
        script.style.display = 'none';
        (document.head || document.documentElement).appendChild(script);
      }
      
      console.log('✅ 扩展检测事件已触发');
    } catch (error) {
      console.error('❌ 触发扩展检测事件失败:', error);
    }
  }
  
  // 立即触发一次
  triggerExtensionDetected();
  
  // 在不同时机多次触发
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', triggerExtensionDetected);
  }
  
  // 延迟触发，确保页面能检测到
  setTimeout(triggerExtensionDetected, 100);
  setTimeout(triggerExtensionDetected, 500);
  setTimeout(triggerExtensionDetected, 1000);
  setTimeout(triggerExtensionDetected, 2000);
  setTimeout(triggerExtensionDetected, 3000);
  
  console.log('🔧 background-open content script 初始化完成');
})();

// Configuration
const CONFIG = {
  // Selectors for links that should open in background
  linkSelectors: [
    'a[href]',
    'a[data-background-tab]',
    '.background-tab-link'
  ],
  
  // Attributes that indicate background opening
  backgroundAttributes: [
    'data-background-tab',
    'data-bg-tab',
    'rel="background"'
  ],
  
  // Modifier keys for background opening
  modifierKeys: {
    ctrl: false,  // Ctrl+Click
    shift: false, // Shift+Click
    alt: false,   // Alt+Click
    meta: false   // Cmd+Click (Mac)
  }
};

// 跟踪所有活跃的setTimeout ID
let activeTimeouts = new Set();
let batchTerminated = false;

// Initialize the content script
function init() {
  // Add event listeners for link clicks
  document.addEventListener('click', handleLinkClick, true);
  
  // Add visual indicators for background tab links
  addVisualIndicators();
  
  console.log('Background Tab Opener content script loaded');
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  console.log('content.js 收到来自background的消息:', message);
  
  // 处理自关闭消息
  if (message && message.action === 'closeSelf') {
    console.log('content.js 收到自关闭消息，尝试关闭当前标签页');
    try {
      // 尝试关闭当前标签页
      window.close();
      console.log('content.js 已执行window.close()');
    } catch (error) {
      console.error('content.js 关闭标签页失败:', error);
    }
    
    if (sendResponse) {
      sendResponse({ success: true });
    }
    return true;
  }
  
  // 处理其他background消息
  if (message.action === "tabOpened") {
    // Handle progress updates for multiple tabs
    console.log(`Tab opened: ${message.progress.url}`);
    
    // Update UI if needed
    updateProgressIndicator(message.progress);
  }
});

// Listen for messages from the webpage
window.addEventListener('message', function(event) {
  if (event.source !== window) return;
  
  if (event.data && event.data.type === 'BATCH_OPEN_URLS') {
    console.log('content.js 收到 BATCH_OPEN_URLS', event.data);
    
    // 重置终止状态
    batchTerminated = false;
    
    const { urls, mode, cycleCount, openCount, openInterval, enableRandomization, randomVariation, urlOpenPlan, maxTabs } = event.data;
    let total = 1;
    let count = 0;
    
    if (mode === 'multi') {
      // 为每个URL创建打开任务 - 循环模式
      let globalIndex = 0; // 全局索引，用于计算延时
      
      // 使用前端发送的预计算计划，如果没有则使用默认值
      let urlOpenCounts = urlOpenPlan;
      let actualTotal = 0;
      
      if (!urlOpenCounts) {
        // 如果没有预计算计划，使用默认的1次打开
        urlOpenCounts = [];
        for (let cycle = 0; cycle < cycleCount; cycle++) {
          const cycleCounts = [];
          urls.forEach(() => {
            cycleCounts.push(1);
            actualTotal += 1;
          });
          urlOpenCounts.push(cycleCounts);
        }
      } else {
        // 计算预计算计划的总数
        urlOpenCounts.forEach(cycleCounts => {
          cycleCounts.forEach(count => {
            actualTotal += count;
          });
        });
      }
      
      // 更新总数为实际计算的值
      total = actualTotal;
      console.log(`content.js 使用前端预计算计划，实际总打开次数: ${total}, URL数量: ${urls.length}, 循环次数: ${cycleCount}`);
      console.log(`content.js URL打开次数分布:`, urlOpenCounts);
      
      // 执行实际的打开操作
      for (let cycle = 0; cycle < cycleCount; cycle++) {
        // 依次打开输入的URL，完成所有输入URL打开一轮为一个循环
        for (let urlIndex = 0; urlIndex < urls.length; urlIndex++) {
          const url = urls[urlIndex];
          // 使用预计算的打开次数
          const repeatCount = urlOpenCounts[cycle][urlIndex];
          
          if (repeatCount === 0) {
            console.log(`content.js 随机跳过 (第${cycle + 1}轮, URL${urlIndex + 1}/${urls.length}): ${url}`);
            // 跳过时不增加count，因为实际没有打开任何标签页
            continue; // 跳过这个URL，继续下一个
          }
          
          // 根据repeatCount决定打开次数
          for (let repeat = 0; repeat < repeatCount; repeat++) {
            const timeoutId = setTimeout(() => {
              // 从活跃列表中移除
              activeTimeouts.delete(timeoutId);
              
              // 检查是否已终止
              if (batchTerminated) {
                console.log('content.js 检测到终止，跳过 openUrl');
                return;
              }
              
              const repeatText = repeatCount > 1 ? ` (重复${repeat + 1}/${repeatCount})` : '';
              console.log(`content.js 发送 openUrl (第${cycle + 1}轮, URL${urlIndex + 1}/${urls.length}): ${url}${repeatText}, 延时: ${globalIndex * (openInterval || 1)}秒`);
              try {
                chrome.runtime.sendMessage({ action: 'openUrl', url, maxTabs }, function(response) {
                  if (chrome.runtime.lastError) {
                    console.error('content.js 发送openUrl消息失败:', chrome.runtime.lastError.message || chrome.runtime.lastError);
                    // 不抛出错误，继续执行
                  } else {
                    console.log('content.js openUrl消息发送成功');
                  }
                });
              } catch (error) {
                console.error('content.js 发送openUrl消息异常:', error.message || error);
                // 不抛出错误，继续执行
              }
              count++;
              window.postMessage({ type: 'BATCH_OPEN_PROGRESS', progress: count / total, count, total }, '*');
            }, globalIndex * (openInterval || 1) * 1000);
            
            // 添加到活跃列表
            activeTimeouts.add(timeoutId);
            globalIndex++; // 递增全局索引
          }
        }
      }
    } else if (mode === 'single' && urls.length > 0) {
      total = openCount || 1;
      for (let i = 0; i < openCount; i++) {
        const timeoutId = setTimeout(() => {
          // 从活跃列表中移除
          activeTimeouts.delete(timeoutId);
          
          // 检查是否已终止
          if (batchTerminated) {
            console.log('content.js 检测到终止，跳过 openUrl');
            return;
          }
          
          console.log('content.js 发送 openUrl', urls[0]);
          try {
            chrome.runtime.sendMessage({ action: 'openUrl', url: urls[0], maxTabs }, function(response) {
              if (chrome.runtime.lastError) {
                console.error('content.js 发送openUrl消息失败:', chrome.runtime.lastError.message || chrome.runtime.lastError);
                // 不抛出错误，继续执行
              } else {
                console.log('content.js openUrl消息发送成功');
              }
            });
          } catch (error) {
            console.error('content.js 发送openUrl消息异常:', error.message || error);
            // 不抛出错误，继续执行
          }
          count++;
          window.postMessage({ type: 'BATCH_OPEN_PROGRESS', progress: count / total, count, total }, '*');
        }, i * (openInterval || 1) * 1000);
        
        // 添加到活跃列表
        activeTimeouts.add(timeoutId);
      }
    }
  }
  
  if (event.data && event.data.type === 'BATCH_CLOSE_ALL_TABS') {
    console.log('content.js 收到 BATCH_CLOSE_ALL_TABS');
    try {
      chrome.runtime.sendMessage({ action: 'closeAllBatchTabs' }, function(response) {
        if (chrome.runtime.lastError) {
          console.error('content.js 发送closeAllBatchTabs消息失败:', chrome.runtime.lastError.message || chrome.runtime.lastError);
          // 不抛出错误，继续执行
        } else {
          console.log('content.js closeAllBatchTabs消息发送成功');
        }
      });
    } catch (error) {
      console.error('content.js 发送closeAllBatchTabs消息异常:', error.message || error);
      // 不抛出错误，继续执行
    }
  }
  
  // 新增：处理终止消息
  if (event.data && event.data.type === 'BATCH_TERMINATE') {
    console.log('content.js 收到 BATCH_TERMINATE，开始终止流程');
    
    // 设置终止标志
    batchTerminated = true;
    
    // 清除所有活跃的setTimeout
    activeTimeouts.forEach(timeoutId => {
      clearTimeout(timeoutId);
      console.log('content.js 清除超时任务:', timeoutId);
    });
    activeTimeouts.clear();
    
    // 通知background.js终止
    try {
      chrome.runtime.sendMessage({ action: 'terminateBatchOpen' }, function(response) {
        if (chrome.runtime.lastError) {
          console.error('content.js 发送terminateBatchOpen消息失败:', chrome.runtime.lastError.message || chrome.runtime.lastError);
          // 不抛出错误，继续执行
        } else {
          console.log('content.js terminateBatchOpen消息发送成功');
        }
      });
    } catch (error) {
      console.error('content.js 发送terminateBatchOpen消息异常:', error.message || error);
      // 不抛出错误，继续执行
    }
    
    console.log('content.js 终止流程完成');
  }
});

// Handle link click events
function handleLinkClick(event) {
  const link = event.target.closest('a[href]');
  if (!link) return;
  
  // Check if this link should open in background
  if (shouldOpenInBackground(link, event)) {
    event.preventDefault();
    event.stopPropagation();
    
    const url = link.href;
    openInBackgroundTab(url, link);
  }
}

// Determine if a link should open in background
function shouldOpenInBackground(link, event) {
  // Check for background attributes
  for (const attr of CONFIG.backgroundAttributes) {
    if (link.hasAttribute(attr.replace('data-', '').replace('rel="', '').replace('"', ''))) {
      return true;
    }
  }
  
  // Check for modifier keys
  if (CONFIG.modifierKeys.ctrl && event.ctrlKey) return true;
  if (CONFIG.modifierKeys.shift && event.shiftKey) return true;
  if (CONFIG.modifierKeys.alt && event.altKey) return true;
  if (CONFIG.modifierKeys.meta && event.metaKey) return true;
  
  // Check for specific classes or IDs
  if (link.classList.contains('background-tab-link')) return true;
  if (link.id && link.id.includes('background-tab')) return true;
  
  return false;
}

// Open URL in background tab
function openInBackgroundTab(url, linkElement) {
  // Send message to background script
  try {
    chrome.runtime.sendMessage({
      action: "openBackgroundTab",
      url: url,
      source: {
        page: window.location.href,
        linkText: linkElement.textContent.trim(),
        linkTitle: linkElement.title || linkElement.textContent.trim()
      }
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('content.js 发送openBackgroundTab消息失败:', chrome.runtime.lastError.message || chrome.runtime.lastError);
        return;
      }
      
      if (response && response.success) {
        // Show success indicator
        showSuccessIndicator(linkElement);
        
        // Optional: Add to opened tabs tracking
        trackOpenedTab(url, response.tabId);
      } else {
        console.error('Failed to open background tab:', response);
      }
    });
  } catch (error) {
    console.error('content.js 发送openBackgroundTab消息异常:', error);
  }
}

// Show visual success indicator
function showSuccessIndicator(linkElement) {
  // Add temporary success class
  linkElement.classList.add('background-tab-opened');
  
  // Remove after animation
  setTimeout(() => {
    linkElement.classList.remove('background-tab-opened');
  }, 1000);
}

// Track opened tabs (optional)
function trackOpenedTab(url, tabId) {
  // Store in session storage for tracking
  const openedTabs = JSON.parse(sessionStorage.getItem('backgroundTabs') || '[]');
  openedTabs.push({
    url: url,
    tabId: tabId,
    openedAt: new Date().toISOString()
  });
  sessionStorage.setItem('backgroundTabs', JSON.stringify(openedTabs));
}

// Add visual indicators to background tab links
function addVisualIndicators() {
  const links = document.querySelectorAll(CONFIG.linkSelectors.join(', '));
  
  links.forEach(link => {
    if (shouldOpenInBackground(link, {})) {
      link.classList.add('background-tab-indicator');
      
      // Add tooltip
      if (!link.title) {
        link.title = 'Opens in background tab';
      }
    }
  });
}

// Handle messages from background script
function handleBackgroundMessage(message, sender, sendResponse) {
  if (message.action === "tabOpened") {
    // Handle progress updates for multiple tabs
    console.log(`Tab opened: ${message.progress.url}`);
    
    // Update UI if needed
    updateProgressIndicator(message.progress);
  }
}

// Handle batch open request from webpage
function handleBatchOpenRequest(data) {
  const { urls, interval = 500 } = data;
  
  if (!urls || !Array.isArray(urls) || urls.length === 0) {
    sendResponseToPage({
      type: 'BATCH_OPEN_RESPONSE',
      success: false,
      error: 'No valid URLs provided'
    });
    return;
  }
  
  // Send message to background script to open multiple tabs
  try {
    chrome.runtime.sendMessage({
      action: "openMultipleBackgroundTabs",
      urls: urls,
      interval: interval
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('content.js 发送openMultipleBackgroundTabs消息失败:', chrome.runtime.lastError);
        sendResponseToPage({
          type: 'BATCH_OPEN_RESPONSE',
          success: false,
          error: 'Connection failed: ' + chrome.runtime.lastError.message
        });
        return;
      }
      
      if (response && response.success) {
        sendResponseToPage({
          type: 'BATCH_OPEN_RESPONSE',
          success: true,
          message: `Opening ${urls.length} tabs in background`,
          total: urls.length
        });
      } else {
        sendResponseToPage({
          type: 'BATCH_OPEN_RESPONSE',
          success: false,
          error: 'Failed to open tabs'
        });
      }
    });
  } catch (error) {
    console.error('content.js 发送openMultipleBackgroundTabs消息异常:', error);
    sendResponseToPage({
      type: 'BATCH_OPEN_RESPONSE',
      success: false,
      error: 'Connection exception: ' + error.message
    });
  }
}

// Send response back to webpage
function sendResponseToPage(response) {
  window.postMessage(response, '*');
}

// Update progress indicator for multiple tabs
function updateProgressIndicator(progress) {
  // Find or create progress indicator
  let indicator = document.getElementById('background-tab-progress');
  if (!indicator) {
    indicator = document.createElement('div');
    indicator.id = 'background-tab-progress';
    indicator.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #4CAF50;
      color: white;
      padding: 10px 15px;
      border-radius: 5px;
      z-index: 10000;
      font-size: 14px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    `;
    document.body.appendChild(indicator);
  }
  
  indicator.textContent = `Opening tabs: ${progress.current}/${progress.total}`;
  
  // Remove indicator when complete
  if (progress.current >= progress.total) {
    setTimeout(() => {
      if (indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
      }
    }, 2000);
  }
}

// Add CSS styles for visual indicators
function addStyles() {
  const style = document.createElement('style');
  style.textContent = `
    .background-tab-indicator::after {
      content: "↗";
      margin-left: 4px;
      font-size: 12px;
      opacity: 0.7;
    }
    
    .background-tab-opened {
      animation: backgroundTabSuccess 1s ease-in-out;
    }
    
    @keyframes backgroundTabSuccess {
      0% { background-color: transparent; }
      50% { background-color: #4CAF50; color: white; }
      100% { background-color: transparent; }
    }
  `;
  document.head.appendChild(style);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    addStyles();
    init();
  });
} else {
  addStyles();
  init();
} 