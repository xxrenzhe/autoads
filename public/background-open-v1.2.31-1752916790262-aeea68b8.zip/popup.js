// Popup script for Background Tab Opener extension

// DOM elements
const ctrlKeyCheckbox = document.getElementById('ctrlKey');
const shiftKeyCheckbox = document.getElementById('shiftKey');
const altKeyCheckbox = document.getElementById('altKey');
const metaKeyCheckbox = document.getElementById('metaKey');
const openCurrentPageButton = document.getElementById('openCurrentPage');
const clearOpenedTabsButton = document.getElementById('clearOpenedTabs');
const statusDiv = document.getElementById('status');

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  setupEventListeners();
  updateStatus();
});

// Load saved settings
function loadSettings() {
  chrome.storage.sync.get({
    modifierKeys: {
      ctrl: false,
      shift: false,
      alt: false,
      meta: false
    }
  }, (result) => {
    ctrlKeyCheckbox.checked = result.modifierKeys.ctrl;
    shiftKeyCheckbox.checked = result.modifierKeys.shift;
    altKeyCheckbox.checked = result.modifierKeys.alt;
    metaKeyCheckbox.checked = result.modifierKeys.meta;
  });
}

// Save settings
function saveSettings() {
  const settings = {
    modifierKeys: {
      ctrl: ctrlKeyCheckbox.checked,
      shift: shiftKeyCheckbox.checked,
      alt: altKeyCheckbox.checked,
      meta: metaKeyCheckbox.checked
    }
  };
  
  chrome.storage.sync.set(settings, () => {
    showStatus('Settings saved', 'success');
    
    // Notify content scripts of settings change
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'settingsUpdated',
          settings: settings
        });
      }
    });
  });
}

// Setup event listeners
function setupEventListeners() {
  // Modifier key checkboxes
  ctrlKeyCheckbox.addEventListener('change', saveSettings);
  shiftKeyCheckbox.addEventListener('change', saveSettings);
  altKeyCheckbox.addEventListener('change', saveSettings);
  metaKeyCheckbox.addEventListener('change', saveSettings);
  
  // Quick action buttons
  openCurrentPageButton.addEventListener('click', openCurrentPageInBackground);
  clearOpenedTabsButton.addEventListener('click', clearOpenedTabsHistory);
}

// Open current page in background tab
function openCurrentPageInBackground() {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      chrome.runtime.sendMessage({
        action: "openBackgroundTab",
        url: tabs[0].url
      }, (response) => {
        if (response && response.success) {
          showStatus('Current page opened in background', 'success');
        } else {
          showStatus('Failed to open page in background', 'error');
        }
      });
    }
  });
}

// Clear opened tabs history
function clearOpenedTabsHistory() {
  // Clear from session storage in current tab
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'clearOpenedTabs'
      });
    }
  });
  
  // Clear from extension storage
  chrome.storage.local.remove('openedTabs', () => {
    showStatus('Opened tabs history cleared', 'success');
  });
}

// Update status display
function updateStatus() {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      // Check if content script is active
      chrome.tabs.sendMessage(tabs[0].id, {action: 'ping'}, (response) => {
        if (chrome.runtime.lastError) {
          showStatus('Extension not active on this page', 'error');
        } else {
          showStatus('Extension is active', 'success');
        }
      });
    }
  });
}

// Show status message
function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
  
  // Auto-hide after 3 seconds
  setTimeout(() => {
    statusDiv.textContent = 'Extension is active';
    statusDiv.className = 'status success';
  }, 3000);
}

// Get opened tabs count
function getOpenedTabsCount() {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'getOpenedTabsCount'
      }, (response) => {
        if (response && response.count !== undefined) {
          console.log(`Opened tabs count: ${response.count}`);
        }
      });
    }
  });
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'tabOpened') {
    // Update status when a tab is opened
    showStatus(`Tab opened: ${message.progress.url}`, 'success');
  }
}); 