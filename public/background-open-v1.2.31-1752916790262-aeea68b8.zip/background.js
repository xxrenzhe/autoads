// Background service worker for Background Tab Opener extension

let batchTabIds = [];
let batchTerminated = false;
let currentBatchId = null;
let activeTimeouts = new Set(); // 跟踪所有活跃的setTimeout

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  console.log('background.js 收到消息', message);

  // 处理ping消息，用于插件检测
  if (message && message.action === 'ping') {
    console.log('background.js 收到ping，响应pong');
    if (sendResponse) {
      sendResponse({ success: true, message: 'pong', extensionId: chrome.runtime.id });
    }
    return true;
  }

  // 处理终止批量打开的消息（支持两种格式）
  if ((message && message.type === 'BATCH_TERMINATE') ||
    (message && message.action === 'terminateBatchOpen')) {
    console.log('background.js 收到终止消息，开始终止流程');

    // 1. 设置终止标志
    batchTerminated = true;
    currentBatchId = null;

    // 2. 清除所有活跃的setTimeout
    activeTimeouts.forEach(timeoutId => {
      clearTimeout(timeoutId);
      console.log('background.js 清除超时任务:', timeoutId);
    });
    activeTimeouts.clear();

    // 3. 发送终止确认消息给前端（增加错误处理）
    try {
      chrome.runtime.sendMessage({
        type: 'BATCH_TERMINATE_CONFIRMED',
        success: true,
        message: '批量打开已完全终止'
      }, function(response) {
        if (chrome.runtime.lastError) {
          console.log('background.js 发送终止确认消息失败:', chrome.runtime.lastError);
          // 不抛出错误，因为这不是关键操作
        }
      });
    } catch (error) {
      console.log('background.js 发送终止确认消息异常:', error);
    }

    console.log('background.js 终止流程完成');

    // 发送响应确认终止成功
    if (sendResponse) {
      sendResponse({ success: true, message: '批量打开已终止' });
    }
    return true; // 保持消息通道开放
  }

  if (message && message.action === 'openUrl' && message.url) {
    console.log('background.js 收到 openUrl', message.url, batchTabIds);
    
    // 获取maxTabs参数，默认为10
    const maxTabs = message.maxTabs || 10;
    
    // 立即发送响应，避免消息端口关闭
    if (sendResponse) {
      sendResponse({ success: true, message: 'openUrl请求已接收' });
    }
    
    // 添加延迟以避免标签页操作冲突
    setTimeout(() => {
      // 队列已满，先关闭最早的标签页
      if (batchTabIds.length >= maxTabs) {
        const oldestTabId = batchTabIds.shift();
        if (oldestTabId !== undefined) {
          // 先检查标签页是否还存在
          chrome.tabs.get(oldestTabId, function(tab) {
            if (chrome.runtime.lastError) {
              console.log('background.js 标签页不存在，跳过关闭:', oldestTabId, chrome.runtime.lastError.message);
              // 标签页不存在，直接创建新标签页
              setTimeout(() => {
                chrome.tabs.create({ url: message.url, active: false }, function (tab) {
                  if (chrome.runtime.lastError) {
                    console.error('background.js 创建标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
                    return;
                  }
                  if (tab && tab.id !== undefined) {
                    batchTabIds.push(tab.id);
                    console.log('background.js 新标签页已打开', tab.id, batchTabIds);
                  }
                });
              }, 100);
            } else {
              // 标签页存在，尝试关闭
              chrome.tabs.remove(oldestTabId, function () {
                if (chrome.runtime.lastError) {
                  console.error('background.js 关闭旧标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
                } else {
                  console.log('background.js 成功关闭旧标签页:', oldestTabId);
                }
                
                // 添加延迟后再创建新标签页
                setTimeout(() => {
                  chrome.tabs.create({ url: message.url, active: false }, function (tab) {
                    if (chrome.runtime.lastError) {
                      console.error('background.js 创建标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
                      return;
                    }
                    if (tab && tab.id !== undefined) {
                      batchTabIds.push(tab.id);
                      console.log('background.js 新标签页已打开', tab.id, batchTabIds);
                    }
                  });
                }, 100); // 100ms延迟
              });
            }
          });
        }
        return;
      }
      
      // 队列未满，直接打开
      chrome.tabs.create({ url: message.url, active: false }, function (tab) {
        if (chrome.runtime.lastError) {
          console.error('background.js 创建标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
          return;
        }
        if (tab && tab.id !== undefined) {
          batchTabIds.push(tab.id);
          console.log('background.js 新标签页已打开', tab.id, batchTabIds);
        }
      });
    }, 50); // 50ms延迟以避免冲突
    
    return true; // 保持消息通道开放
  }

  if (message && message.action === 'batchOpen' && message.params) {
    console.log('background.js 收到 batchOpen，当前记录的标签页数量:', batchTabIds.length);
    // 修复：每次批量打开前先关闭所有已记录的批量标签页
    if (batchTabIds.length > 0) {
      console.log('background.js 先关闭已有标签页:', batchTabIds);
      try {
        chrome.tabs.remove(batchTabIds, function () {
          if (chrome.runtime.lastError) {
            console.error('background.js 关闭已有标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
          } else {
            console.log('background.js 已有标签页关闭成功');
          }
          batchTabIds = [];
          // 继续后续批量打开逻辑
          doBatchOpen(message, sendResponse);
        });
      } catch (error) {
        console.error('background.js 关闭已有标签页异常:', error);
        batchTabIds = [];
        doBatchOpen(message, sendResponse);
      }
      return true;
    } else {
      console.log('background.js 没有已有标签页，直接开始批量打开');
      doBatchOpen(message, sendResponse);
      return true;
    }
  }

  if (message && message.action === 'closeAllBatchTabs') {
    console.log('background.js 收到 closeAllBatchTabs', batchTabIds);
    
    // 立即发送响应，避免消息端口关闭
    if (sendResponse) {
      sendResponse({ success: true, message: 'closeAllBatchTabs请求已接收' });
    }
    
    if (batchTabIds.length > 0) {
      console.log('background.js 尝试关闭标签页，数量:', batchTabIds.length);
      console.log('background.js 要关闭的标签页ID:', batchTabIds);
      
      // 检查chrome.tabs API是否可用
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.remove) {
        console.log('background.js Chrome tabs API 可用，开始关闭标签页');
        try {
          // 尝试逐个关闭标签页，提高成功率
          const tabsToClose = [...batchTabIds]; // 复制数组
          let closedCount = 0;
          
          tabsToClose.forEach((tabId, index) => {
            setTimeout(() => {
              // 先检查标签页是否还存在
              chrome.tabs.get(tabId, function(tab) {
                if (chrome.runtime.lastError) {
                  console.log(`background.js 标签页 ${tabId} 不存在，跳过关闭:`, chrome.runtime.lastError.message);
                  closedCount++;
                  // 如果是最后一个标签页，清空记录
                  if (closedCount === tabsToClose.length) {
                    console.log('background.js 所有标签页关闭完成');
                    batchTabIds = [];
                  }
                } else {
                  // 标签页存在，尝试关闭
                  chrome.tabs.remove(tabId, function () {
                    closedCount++;
                    if (chrome.runtime.lastError) {
                      console.error(`background.js 关闭标签页 ${tabId} 时出错:`, chrome.runtime.lastError.message || chrome.runtime.lastError);
                    } else {
                      console.log(`background.js 已关闭标签页 ${tabId}`);
                    }
                    
                    // 如果是最后一个标签页，清空记录
                    if (closedCount === tabsToClose.length) {
                      console.log('background.js 所有标签页关闭完成');
                      batchTabIds = [];
                    }
                  });
                }
              });
            }, index * 100); // 每个标签页间隔100ms关闭
          });
          
        } catch (error) {
          console.error('background.js 调用chrome.tabs.remove时异常:', error);
          batchTabIds = []; // 清空记录，避免重复尝试
        }
      } else {
        console.error('background.js Chrome tabs API 不可用');
        console.log('background.js 尝试备用关闭方案...');
        
        // 备用方案：通过content script尝试关闭
        try {
          // 发送消息给所有标签页，让它们自己关闭
          batchTabIds.forEach(tabId => {
            chrome.tabs.sendMessage(tabId, { action: 'closeSelf' }, function(response) {
              if (chrome.runtime.lastError) {
                console.log(`无法向标签页 ${tabId} 发送关闭消息:`, chrome.runtime.lastError);
              }
            });
          });
          console.log('background.js 已发送自关闭消息给所有标签页');
        } catch (error) {
          console.error('background.js 备用关闭方案失败:', error);
        }
        
        batchTabIds = []; // 清空记录
      }
    } else {
      console.log('background.js 没有需要关闭的标签页');
    }
    
    return true; // 保持消息通道开放
  }
});

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("Background Tab Opener extension installed");
  }
});

// Handle tab updates to maintain focus control
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Optional: Add any additional tab management logic here
  if (changeInfo.status === "complete") {
    // Tab has finished loading
  }
});

// 新增：抽取批量打开逻辑为函数，便于复用
function doBatchOpen(message, sendResponse) {
  const { urls, mode, cycleCount, openCount, openInterval, maxTabs } = message.params;
  let totalToOpen = 0;
  let urlList = [];
  if (mode === 'multi') {
    for (let i = 0; i < (cycleCount || 1); i++) {
      urlList = urlList.concat(urls);
    }
    totalToOpen = urlList.length;
  } else if (mode === 'single') {
    urlList = Array(openCount || 1).fill(urls[0]);
    totalToOpen = urlList.length;
  }
  let opened = 0;
  batchTerminated = false;
  currentBatchId = Date.now() + '-' + Math.random();
  const thisBatchId = currentBatchId;
  
  function openNext() {
    if (batchTerminated || thisBatchId !== currentBatchId) {
      console.log('background.js 批量打开被终止，openNext退出');
      return;
    }
    if (opened >= totalToOpen) return;
    const url = urlList[opened];
    
    // 队列已满，先关闭最早的标签页
    if (batchTabIds.length >= (maxTabs || 10)) {
      const oldestTabId = batchTabIds.shift();
      if (oldestTabId !== undefined) {
        // 先检查标签页是否还存在
        chrome.tabs.get(oldestTabId, function(tab) {
          if (chrome.runtime.lastError) {
            console.log('background.js doBatchOpen: 标签页不存在，跳过关闭:', oldestTabId, chrome.runtime.lastError.message);
            // 标签页不存在，直接继续下一个
            openNext();
          } else {
            // 标签页存在，尝试关闭
            chrome.tabs.remove(oldestTabId, function () {
              if (chrome.runtime.lastError) {
                console.error('background.js doBatchOpen: 关闭旧标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
              } else {
                console.log('background.js doBatchOpen: 成功关闭旧标签页:', oldestTabId);
              }
              
              // 再次检查终止状态
              if (batchTerminated || thisBatchId !== currentBatchId) {
                console.log('background.js 在创建标签页前检测到终止');
                return;
              }
              
              // 创建新标签页
              chrome.tabs.create({ url: url, active: false }, function (tab) {
                if (chrome.runtime.lastError) {
                  console.error('background.js 创建标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
                  return;
                }
                if (tab && tab.id !== undefined) {
                  batchTabIds.push(tab.id);
                  opened++;
                  
                  // 再次检查终止状态
                  if (batchTerminated || thisBatchId !== currentBatchId) {
                    console.log('background.js 在发送进度前检测到终止');
                    return;
                  }
                  
                  // 发送进度更新
                  try {
                    chrome.runtime.sendMessage({
                      type: 'BATCH_OPEN_PROGRESS',
                      progress: opened / totalToOpen,
                      count: opened,
                      total: totalToOpen
                    }, function(response) {
                      if (chrome.runtime.lastError) {
                        console.log('background.js 发送进度消息失败:', chrome.runtime.lastError);
                      }
                    });
                  } catch (error) {
                    console.log('background.js 发送进度消息异常:', error);
                  }
                  
                  // 设置下一次打开前再次检查终止状态
                  const timeoutId = setTimeout(() => {
                    activeTimeouts.delete(timeoutId);
                    if (!batchTerminated && thisBatchId === currentBatchId) {
                      openNext();
                    }
                  }, (openInterval || 5) * 1000);
                  activeTimeouts.add(timeoutId);
                }
              });
            });
          }
        });
        return;
      }
    }
    
    // 队列未满，直接打开
    console.log(`background.js 尝试创建标签页: ${url}`);
    chrome.tabs.create({ url: url, active: false }, function (tab) {
      console.log('background.js chrome.tabs.create 回调执行，tab:', tab);
      console.log('background.js chrome.runtime.lastError:', chrome.runtime.lastError);
      
      if (chrome.runtime.lastError) {
        console.error('background.js 创建标签页时出错:', chrome.runtime.lastError.message || chrome.runtime.lastError);
        return;
      }
      
      if (tab && tab.id !== undefined) {
        console.log(`background.js 标签页创建成功，ID: ${tab.id}`);
        batchTabIds.push(tab.id);
        console.log('background.js 当前记录的标签页ID数组:', batchTabIds);
        opened++;
        
        // 再次检查终止状态
        if (batchTerminated || thisBatchId !== currentBatchId) {
          console.log('background.js 在发送进度前检测到终止（队列未满分支）');
          return;
        }
        
        console.log(`background.js 发送进度更新: ${opened}/${totalToOpen}`);
        try {
          chrome.runtime.sendMessage({
            type: 'BATCH_OPEN_PROGRESS',
            progress: opened / totalToOpen,
            count: opened,
            total: totalToOpen
          }, function(response) {
            if (chrome.runtime.lastError) {
              console.log('background.js 发送进度消息失败:', chrome.runtime.lastError);
            }
          });
        } catch (error) {
          console.log('background.js 发送进度消息异常:', error);
        }
        
        // 设置下一次打开前再次检查终止状态
        const timeoutId = setTimeout(() => {
          activeTimeouts.delete(timeoutId);
          if (!batchTerminated && thisBatchId === currentBatchId) {
            console.log('background.js 继续打开下一个标签页');
            openNext();
          }
        }, (openInterval || 5) * 1000);
        activeTimeouts.add(timeoutId);
      } else {
        console.error('background.js 标签页创建失败，tab对象无效:', tab);
      }
    });
  }
  
  openNext();
  sendResponse({ success: true, message: '批量打开已开始' });
} 